(() => {
    "use strict";
    var decodeEntities = (function() {
        // this prevents any overhead from creating the object each time
        var element = document.createElement('div');

        function decodeHTMLEntities (str) {
            if(str && typeof str === 'string') {
                // strip script/html tags
                str = str.replace(/<script[^>]*>([\S\s]*?)<\/script>/gmi, '');
                str = str.replace(/<\/?\w(?:[^"'>]|"[^"]*"|'[^']*')*>/gmi, '');
                element.innerHTML = str;
                str = element.textContent;
                element.textContent = '';
            }

            return str;
        }

        return decodeHTMLEntities;
    })();
    // Получение зависимостей из глобального объекта
    const paymentRegistry = window.wc.wcBlocksRegistry; // Реестр платежных методов WooCommerce
    const wcSettings = window.wc.wcSettings; // Настройки WooCommerce

    // Извлечение данных для метода оплаты из настроек WooCommerce
    const eposSettings = wcSettings.getSetting("epos_data", {});
    // Локализованное название и описание платежного метода
    const defaultTitle = "EPOS";
    const methodTitle = decodeEntities(eposSettings.title) || defaultTitle;
    const descriptionComponent = () => {
        return React.createElement(
            "div",
            null,
            decodeEntities(eposSettings.description || "")
        );
    };

    // Конфигурация метода оплаты
    const payshopMethod = {
        name: "epos",
        label: React.createElement(
            (props) => {
                // Отображение значка и названия метода
                /* const iconElement = React.createElement("img", {
                    src: eposSettings.icon,
                    width: eposSettings.icon_width,
                    height: eposSettings.icon_height,
                    style: { display: "inline" },
                });
                */
                return React.createElement(
                    "span",
                    { className: "wc-block-components-payment-method-label wc-block-components-payment-method-label--with-icon" },
                    // iconElement,
                    decodeEntities(eposSettings.title) || defaultTitle
                );
            },
            null
        ),
        content: React.createElement(descriptionComponent, null),
        edit: React.createElement(descriptionComponent, null),
        icons: null,
        canMakePayment: (context) => {
            // Проверка возможности использования метода оплаты
            //if (context.cartTotals.currency_code !== "BYN") {
            //    return false; // Метод доступен только для BYN
            //}
            return true; // Метод доступен
        },
        ariaLabel: methodTitle,
        //supports: {
        //    features: eposSettings.supports,
        //},
    };

    // Регистрация метода оплаты в WooCommerce
    paymentRegistry.registerPaymentMethod(payshopMethod);
})();