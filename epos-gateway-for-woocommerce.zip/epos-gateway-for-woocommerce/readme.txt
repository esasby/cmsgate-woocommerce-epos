=== EPOS Gateway for WooCommerce ===
Contributors: nmekh
Tags: commerce, woocommerce, epos, shopping, gateway, erip, woo, wc
Stable tag: 2.1.1
Requires at least: 4.6
Tested up to: 6.5.2
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

EPOS (ERIP Belarus) integration for woocommerce

== Description ==
EPOS™ — payment service for invoicing in AIS *Raschet* (ERIP) Belarus.
After invoicing you clients will be available for payment by a plastic card and electronic money, at any of the bank branches, cash desks, ATMs, payment terminals, in the electronic money system, through Internet banking, M-banking, Internet acquiring.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/epos-gateway-for-woocommerce` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Woocommerce->Settings->Payments screen to configure the plugin

== Changelog ==
= 1.1.1 =
* Bug fix: enable/disable checkbox in module settings

= 1.10.0 =
* Bug fix: callbacks

= 1.10.1 =
* Wordpress Plugin Directory initial release

= 1.10.2 =
* Epos URL (ESAS/UPS) fix

= 1.10.3 =
* Bug fix: callback not working

= 1.11.0 =
* New feature: RRB Bank EPOS processing

= 1.12.0 =
* Bug fix: iii auth problems

= 1.13.0 =
* Bug fix: total amount calculation for more then 1 quantity

= 1.13.1 =
* Critical fix: missed files

= 1.13.2 =
* Bug fix: fullName and fullAddress correction

= 1.13.3 =
* Bug fix: fullName split

= 1.13.4 =
* Wordpress 5.8 compatibility

= 1.14.0 =
* QR-code with white background. Latest core update

= 2.0.0 =
* Update to latest core version
* Wordpress 6.2 compatibility
* HRO support

= 2.0.2 =
* Package import fix

= 2.0.3 =
* warnings fix

= 2.0.4 =
* warnings fix

= 2.0.5 =
* Wordpress 6.5.2 compatibility
* Woocommerce 8.8.2 compatibility

= 2.1.1 =
* WebPay to PayRaschetBy conversion
* Use Blocks